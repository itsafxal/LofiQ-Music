﻿========================================================================
LofiQ Desktop Music Player - Portable Edition (v1.0.5)
Website: https://lofiq-web.vercel.app/
Repository: https://github.com/itsafxal/LofiQ-Music
========================================================================

ABOUT PORTABLE EDITION
----------------------
This package is a standalone, fully self-contained distribution of LofiQ
Music Player for 64-bit Windows 10 and Windows 11. It requires no installation
and does not require administrator privileges.

HOW TO RUN:
1. Extract the entire ZIP archive to a folder of your choice (e.g. C:\Users\<You>\LofiQ).
2. Double-click "LofiQ.exe" to start listening.

WINDOWS 11 SMART APP CONTROL & SMARTSCREEN NOTE:
------------------------------------------------
When you download ZIP archives using a web browser, Windows marks the file
with the "Mark of the Web" (Zone.Identifier Alternate Data Stream).

If Windows 11 Smart App Control (SAC) or Windows Defender SmartScreen blocks
execution because this open-source build does not yet have established Microsoft
cloud reputation:

1. Right-click the downloaded "LofiQ-v1.0.5-Windows-Portable.zip" BEFORE extracting.
2. Select "Properties".
3. At the bottom of the "General" tab, check the "Unblock" checkbox.
4. Click "Apply", then "OK".
5. Extract the ZIP and launch "LofiQ.exe".

Alternatively, unblock via PowerShell:
   Unblock-File -Path .\LofiQ-v1.0.5-Windows-Portable.zip

SYSTEM REQUIREMENTS:
--------------------
- OS: Windows 10 or Windows 11 (64-bit x64)
- Runtime: Microsoft Visual C++ 2015-2022 Redistributable (x64)
  If missing, download official runtime from Microsoft:
  https://aka.ms/vs/17/release/vc_redist.x64.exe
- Audio: Core Audio / WASAPI compatible audio output device

FEATURES INCLUDED:
------------------
- True Dual-Player Seamless & Gapless Playback Engine (libmpv / media_kit)
- 10-Band Graphic Equalizer, Bass Boost & Spatializer
- Windows System Media Transport Controls (SMTC) & Hardware Media Keys
- Synchronized LRCLIB Lyrics & Desktop Mini-Player
========================================================================
